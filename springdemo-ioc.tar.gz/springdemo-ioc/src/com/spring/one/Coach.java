package com.spring.one;

public interface Coach {
	
	public void myTraining();

}
