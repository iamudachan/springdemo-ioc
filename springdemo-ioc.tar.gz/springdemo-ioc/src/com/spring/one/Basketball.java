package com.spring.one;

public class Basketball {
	public void myTraining() {
		System.out.println("basket ball");
	}
}
