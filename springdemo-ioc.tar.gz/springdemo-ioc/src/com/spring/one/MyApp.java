package com.spring.one;

import javax.naming.Context;

import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyApp {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("/com/spring/one/applicationContext.xml");
		Coach coach = context.getBean("football",Coach.class);
		Coach coach1 = context.getBean("football",Coach.class);
		
		boolean result = coach == coach1;
		System.out.println(result);
		
		coach.myTraining();
		
		Basketball ball = context.getBean("basketball",Basketball.class);
		ball.myTraining();
	}

}
