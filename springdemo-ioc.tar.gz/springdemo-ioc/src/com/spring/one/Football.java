package com.spring.one;

public class Football implements Coach{
	public Football(String a){
		
	}
	@Override
	public void myTraining() {
		System.out.println("Foot ball");
	}

}
