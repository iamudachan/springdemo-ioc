package com.luv2code.springdemo6;

public interface FortuneService {

	public String getFortune();
	
}
