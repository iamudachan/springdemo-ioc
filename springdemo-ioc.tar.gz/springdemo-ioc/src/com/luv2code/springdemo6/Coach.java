package com.luv2code.springdemo6;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
	
}
