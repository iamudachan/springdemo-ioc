package com.luv2code.springdemo2;

public interface Coach {

	public String getDailyWorkout();
	
}
