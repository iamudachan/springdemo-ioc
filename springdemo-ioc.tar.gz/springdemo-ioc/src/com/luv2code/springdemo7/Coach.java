package com.luv2code.springdemo7;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
	
}
