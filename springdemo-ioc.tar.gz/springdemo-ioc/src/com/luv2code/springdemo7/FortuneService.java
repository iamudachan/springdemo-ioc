package com.luv2code.springdemo7;

public interface FortuneService {

	public String getFortune();
	
}
