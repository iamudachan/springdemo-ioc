package com.luv2code.springdemo5;

public interface FortuneService {

	public String getFortune();
	
}
