package com.luv2code.springdemo5;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
	
}
