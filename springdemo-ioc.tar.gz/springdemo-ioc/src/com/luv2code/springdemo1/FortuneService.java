package com.luv2code.springdemo1;

public interface FortuneService {

	public String getFortune();
	
}
