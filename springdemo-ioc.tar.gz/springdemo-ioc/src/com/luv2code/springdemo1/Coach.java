package com.luv2code.springdemo1;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
	
}
