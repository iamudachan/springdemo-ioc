package com.constructorinjuction;

public class CoachService implements Coach {
	
	public CoachService() {
		System.out.println("12345");
	}

	@Override
	public String myCoach() {
		System.out.println("====================");
		return "My Coach service";
	}

}
