package com.constructorinjuction;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyMain {

	public static void main(String[] args) {

		/*
		 * Service s = null ; Service cs = new CarService(s);
		 * System.out.println(cs.myService());
		 */
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"/com/constructorinjuction/applicationContext.xml");

		Service cs1 = context.getBean("carservice",Service.class);
		System.out.println(cs1.myService());
		
		
	}

}
