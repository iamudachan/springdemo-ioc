package com.constructorinjuction;

public interface Coach {
	public String myCoach();

}
