package com.constructorinjuction;

public interface Service {
	
	public String myService();

}
