package com.constructorinjuction;

public class CarService implements Service {

	Coach coach;
	
	public CarService(Coach coach) {
		this.coach = coach;
	}
	
	@Override
	public String myService() {
		return "My Car Service";
	}

}
